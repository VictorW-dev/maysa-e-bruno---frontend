import { useState, useRef, DragEvent } from 'react';
import { Link, useNavigate } from 'react-router';
import { Camera, Upload as UploadIcon, X, Check, ArrowLeft, Heart } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import * as Progress from '@radix-ui/react-progress';
import * as Checkbox from '@radix-ui/react-checkbox';

interface PhotoPreview {
  id: string;
  file: File;
  preview: string;
}

export default function Upload() {
  const [photos, setPhotos] = useState<PhotoPreview[]>([]);
  const [guestName, setGuestName] = useState('');
  const [message, setMessage] = useState('');
  const [agreed, setAgreed] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadComplete, setUploadComplete] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  const handleFiles = (files: FileList | null) => {
    if (!files) return;
    
    const newPhotos: PhotoPreview[] = Array.from(files)
      .filter(file => file.type.startsWith('image/'))
      .map(file => ({
        id: Math.random().toString(36).substr(2, 9),
        file,
        preview: URL.createObjectURL(file)
      }));
    
    setPhotos(prev => [...prev, ...newPhotos]);
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    handleFiles(e.dataTransfer.files);
  };

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const removePhoto = (id: string) => {
    setPhotos(prev => {
      const photo = prev.find(p => p.id === id);
      if (photo) URL.revokeObjectURL(photo.preview);
      return prev.filter(p => p.id !== id);
    });
  };

  const handleSubmit = async () => {
    if (photos.length === 0 || !agreed) return;

    setIsUploading(true);
    setUploadProgress(0);

    // Simulação de upload
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsUploading(false);
          setUploadComplete(true);
          setTimeout(() => {
            navigate('/gallery');
          }, 2000);
          return 100;
        }
        return prev + 10;
      });
    }, 300);
  };

  if (uploadComplete) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-6" style={{ fontFamily: 'var(--font-sans)' }}>
        <motion.div
          className="text-center"
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
          >
            <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
              <Check className="w-10 h-10 text-white" />
            </div>
          </motion.div>
          <h2 
            className="text-4xl mb-4"
            style={{ fontFamily: 'var(--font-serif)' }}
          >
            Fotos enviadas com sucesso!
          </h2>
          <p className="text-muted-foreground text-lg">
            Obrigado por compartilhar este momento conosco
          </p>
          <Heart className="w-8 h-8 mx-auto mt-6 text-gold" fill="currentColor" />
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white pb-12" style={{ fontFamily: 'var(--font-sans)' }}>
      {/* Header */}
      <header className="sticky top-0 bg-white/95 backdrop-blur-sm border-b border-border z-10 px-6 py-4">
        <div className="max-w-3xl mx-auto flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-5 h-5" />
            <span>Voltar</span>
          </Link>
          <h1 
            className="text-2xl"
            style={{ fontFamily: 'var(--font-serif)' }}
          >
            Enviar Fotos
          </h1>
          <div className="w-20"></div>
        </div>
      </header>

      <div className="max-w-3xl mx-auto px-6 pt-8">
        {/* Upload Area */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <div
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            className={`border-2 border-dashed rounded-2xl p-12 text-center transition-all duration-300 ${
              isDragging 
                ? 'border-gold bg-gold-light' 
                : 'border-border bg-sand hover:border-gold/50'
            }`}
          >
            <Camera className="w-16 h-16 mx-auto mb-6 text-gold" />
            <h3 className="text-xl mb-2">
              Arraste suas fotos aqui
            </h3>
            <p className="text-muted-foreground mb-6">
              ou clique no botão abaixo para selecionar
            </p>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="bg-primary text-white px-8 py-4 rounded-xl hover:bg-primary/90 transition-colors inline-flex items-center gap-2"
            >
              <UploadIcon className="w-5 h-5" />
              Selecionar fotos
            </button>
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept="image/*"
              onChange={(e) => handleFiles(e.target.files)}
              className="hidden"
            />
          </div>
        </motion.div>

        {/* Photo Previews */}
        <AnimatePresence>
          {photos.length > 0 && (
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -20, opacity: 0 }}
              className="mt-8"
            >
              <h3 className="text-lg mb-4">
                {photos.length} {photos.length === 1 ? 'foto selecionada' : 'fotos selecionadas'}
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {photos.map((photo) => (
                  <motion.div
                    key={photo.id}
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.8, opacity: 0 }}
                    className="relative aspect-square rounded-xl overflow-hidden group"
                  >
                    <img 
                      src={photo.preview} 
                      alt="Preview"
                      className="w-full h-full object-cover"
                    />
                    <button
                      onClick={() => removePhoto(photo.id)}
                      className="absolute top-2 right-2 bg-destructive text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Form */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="mt-12 space-y-6"
        >
          <div>
            <label className="block mb-2 text-foreground">
              Seu nome <span className="text-muted-foreground text-sm">(opcional)</span>
            </label>
            <input
              type="text"
              value={guestName}
              onChange={(e) => setGuestName(e.target.value)}
              placeholder="Digite seu nome"
              className="w-full px-6 py-4 rounded-xl bg-sand border border-border focus:border-gold focus:outline-none transition-colors"
            />
          </div>

          <div>
            <label className="block mb-2 text-foreground">
              Mensagem para os noivos <span className="text-muted-foreground text-sm">(opcional)</span>
            </label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Deixe uma mensagem especial..."
              rows={4}
              className="w-full px-6 py-4 rounded-xl bg-sand border border-border focus:border-gold focus:outline-none transition-colors resize-none"
            />
          </div>

          <div className="flex items-start gap-3 bg-sand p-6 rounded-xl">
            <Checkbox.Root
              checked={agreed}
              onCheckedChange={(checked) => setAgreed(checked as boolean)}
              className="w-6 h-6 rounded border-2 border-border bg-white flex items-center justify-center shrink-0 mt-0.5"
              id="agree"
            >
              <Checkbox.Indicator>
                <Check className="w-4 h-4 text-gold" />
              </Checkbox.Indicator>
            </Checkbox.Root>
            <label htmlFor="agree" className="text-sm leading-relaxed cursor-pointer">
              Autorizo o uso das imagens enviadas para a criação de álbum digital e compartilhamento 
              com familiares e amigos dos noivos.
            </label>
          </div>
        </motion.div>

        {/* Upload Progress */}
        <AnimatePresence>
          {isUploading && (
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -20, opacity: 0 }}
              className="mt-8"
            >
              <div className="bg-sand p-6 rounded-xl">
                <p className="mb-4 text-center">Enviando fotos...</p>
                <Progress.Root className="relative overflow-hidden bg-muted rounded-full w-full h-3">
                  <Progress.Indicator
                    className="bg-gold h-full transition-all duration-300 ease-out rounded-full"
                    style={{ width: `${uploadProgress}%` }}
                  />
                </Progress.Root>
                <p className="text-sm text-muted-foreground text-center mt-2">
                  {uploadProgress}%
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Submit Button */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="mt-8"
        >
          <button
            onClick={handleSubmit}
            disabled={photos.length === 0 || !agreed || isUploading}
            className="w-full bg-primary text-white py-6 px-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:shadow-lg"
          >
            {isUploading ? 'Enviando...' : 'Enviar fotos'}
          </button>
        </motion.div>
      </div>
    </div>
  );
}
