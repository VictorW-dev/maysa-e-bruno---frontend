import { Link } from 'react-router';
import { Heart, Camera, Image } from 'lucide-react';
import { motion } from 'motion/react';

export default function Home() {
  return (
    <div className="min-h-screen bg-white" style={{ fontFamily: 'var(--font-sans)' }}>
      {/* Hero Section */}
      <motion.section 
        className="relative h-screen flex items-center justify-center overflow-hidden"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
      >
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1770022006280-dea3726f4477?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb21hbnRpYyUyMGNvdXBsZSUyMHdlZGRpbmclMjBvdXRkb29yfGVufDF8fHx8MTc3MjQ3MTc2Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Maysa & Bruno"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black/50"></div>
        </div>
        
        <div className="relative z-10 text-center text-white px-6 max-w-4xl">
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.8 }}
          >
            <Heart className="w-12 h-12 mx-auto mb-6 text-gold" fill="currentColor" />
            <h1 
              className="text-6xl md:text-8xl mb-4"
              style={{ 
                fontFamily: 'var(--font-serif)',
                fontWeight: '300',
                letterSpacing: '0.05em'
              }}
            >
              Maysa & Bruno
            </h1>
            <div className="w-24 h-px bg-gold mx-auto mb-6"></div>
            <p className="text-xl md:text-2xl mb-2" style={{ fontWeight: '300' }}>
              15 de Junho de 2026
            </p>
          </motion.div>
        </div>

        <motion.div 
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
          initial={{ y: -10, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.8, repeat: Infinity, repeatType: "reverse" }}
        >
          <div className="w-6 h-10 border-2 border-white/50 rounded-full flex items-start justify-center p-2">
            <div className="w-1 h-3 bg-white/70 rounded-full"></div>
          </div>
        </motion.div>
      </motion.section>

      {/* Message */}
      <section className="py-20 px-6 bg-sand">
        <div className="max-w-3xl mx-auto text-center">
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <p 
              className="text-xl md:text-2xl leading-relaxed text-foreground/80 mb-8"
              style={{ fontFamily: 'var(--font-serif)', fontWeight: '300' }}
            >
              Estamos muito felizes em compartilhar este momento especial com você! 
              Ajude-nos a guardar as memórias deste dia enviando suas fotos.
            </p>
          </motion.div>
        </div>
      </section>

      {/* CTA Buttons */}
      <section className="py-20 px-6">
        <div className="max-w-2xl mx-auto">
          <motion.div
            className="space-y-4"
            initial={{ y: 30, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <Link to="/upload">
              <motion.button
                className="w-full bg-primary text-white py-6 px-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center gap-3"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Camera className="w-6 h-6" />
                <span className="text-xl">Enviar suas fotos</span>
              </motion.button>
            </Link>

            <Link to="/gallery">
              <motion.button
                className="w-full bg-sand text-foreground py-6 px-8 rounded-2xl shadow-sm hover:shadow-md transition-all duration-300 border border-border flex items-center justify-center gap-3"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Image className="w-6 h-6" />
                <span className="text-xl">Ver galeria</span>
              </motion.button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* QR Code Section */}
      <section className="py-16 px-6 bg-sand">
        <div className="max-w-md mx-auto text-center">
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h3 
              className="text-2xl mb-6"
              style={{ fontFamily: 'var(--font-serif)' }}
            >
              Acesso rápido
            </h3>
            <div className="bg-white p-8 rounded-2xl shadow-sm inline-block">
              <div className="w-48 h-48 bg-muted rounded-xl flex items-center justify-center">
                <p className="text-muted-foreground text-sm text-center px-4">
                  QR Code<br/>para compartilhar
                </p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground mt-4">
              Escaneie para acessar o site
            </p>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 text-center border-t border-border">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <p 
            className="text-2xl md:text-3xl mb-2"
            style={{ 
              fontFamily: 'var(--font-serif)',
              color: 'var(--gold)'
            }}
          >
            Com amor, Maysa & Bruno
          </p>
          <p className="text-sm text-muted-foreground">
            15.06.2026
          </p>
          
          <Link 
            to="/admin"
            className="inline-block mt-6 text-xs text-muted-foreground/50 hover:text-gold transition-colors"
          >
            Área da noiva
          </Link>
        </motion.div>
      </footer>
    </div>
  );
}