import { useState } from 'react';
import { Link } from 'react-router';
import { ArrowLeft, X, Share2, Clock, Star } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Masonry from 'react-responsive-masonry';
import * as Dialog from '@radix-ui/react-dialog';

interface Photo {
  id: string;
  url: string;
  guestName: string;
  timestamp: string;
  featured?: boolean;
}

const mockPhotos: Photo[] = [
  {
    id: '1',
    url: 'https://images.unsplash.com/photo-1770022006280-dea3726f4477?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb21hbnRpYyUyMGNvdXBsZSUyMHdlZGRpbmclMjBvdXRkb29yfGVufDF8fHx8MTc3MjQ3MTc2Mnww&ixlib=rb-4.1.0&q=80&w=1080',
    guestName: 'Marina Silva',
    timestamp: '2h atrás',
    featured: true
  },
  {
    id: '2',
    url: 'https://images.unsplash.com/photo-1764269719300-7094d6c00533?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwY2VsZWJyYXRpb24lMjBndWVzdHMlMjBkYW5jaW5nfGVufDF8fHx8MTc3MjQ3MTg4MXww&ixlib=rb-4.1.0&q=80&w=1080',
    guestName: 'Carlos Mendes',
    timestamp: '3h atrás'
  },
  {
    id: '3',
    url: 'https://images.unsplash.com/photo-1719223852076-6981754ebf76?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwcmVjZXB0aW9uJTIwdGFibGUlMjBkZWNvcmF0aW9ufGVufDF8fHx8MTc3MjQ3MTg4Mnww&ixlib=rb-4.1.0&q=80&w=1080',
    guestName: 'Ana Paula',
    timestamp: '4h atrás',
    featured: true
  },
  {
    id: '4',
    url: 'https://images.unsplash.com/photo-1584158531321-2a1fefff2e51?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwY2FrZSUyMGVsZWdhbnQlMjB3aGl0ZXxlbnwxfHx8fDE3NzI0NzE4ODJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    guestName: 'Roberto Costa',
    timestamp: '5h atrás'
  },
  {
    id: '5',
    url: 'https://images.unsplash.com/photo-1762941744800-385b067dff21?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwY291cGxlJTIwcG9ydHJhaXQlMjBvdXRkb29yfGVufDF8fHx8MTc3MjQ3MTg4NXww&ixlib=rb-4.1.0&q=80&w=1080',
    guestName: 'Juliana Santos',
    timestamp: '6h atrás',
    featured: true
  },
  {
    id: '6',
    url: 'https://images.unsplash.com/photo-1700142611715-8a023c5eb8c5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwYm91cXVldCUyMGZsb3dlcnMlMjB3aGl0ZXxlbnwxfHx8fDE3NzI0MDYxODR8MA&ixlib=rb-4.1.0&q=80&w=1080',
    guestName: 'Patricia Lima',
    timestamp: '7h atrás'
  },
  {
    id: '7',
    url: 'https://images.unsplash.com/photo-1767986012138-4893f40932d5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwY2VyZW1vbnklMjBhaXNsZSUyMGRlY29yYXRpb258ZW58MXx8fHwxNzcyNDcxODg1fDA&ixlib=rb-4.1.0&q=80&w=1080',
    guestName: 'Fernando Alves',
    timestamp: '8h atrás',
    featured: true
  },
  {
    id: '8',
    url: 'https://images.unsplash.com/photo-1765615202745-550b8859088f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwZ3Vlc3RzJTIwZ3JvdXAlMjBwaG90b3xlbnwxfHx8fDE3NzI0NzE4ODV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    guestName: 'Família Rodrigues',
    timestamp: '9h atrás'
  },
  {
    id: '9',
    url: 'https://images.unsplash.com/photo-1630326844982-9b35b01cfe59?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWRkaW5nJTIwcmluZ3MlMjBjbG9zZSUyMHVwfGVufDF8fHx8MTc3MjQzOTg3Nnww&ixlib=rb-4.1.0&q=80&w=1080',
    guestName: 'Lucas Pereira',
    timestamp: '10h atrás'
  }
];

export default function Gallery() {
  const [filter, setFilter] = useState<'recent' | 'featured'>('recent');
  const [selectedPhoto, setSelectedPhoto] = useState<Photo | null>(null);

  const filteredPhotos = filter === 'featured' 
    ? mockPhotos.filter(p => p.featured)
    : mockPhotos;

  const handleShare = (photo: Photo) => {
    // Simulação de compartilhamento
    console.log('Compartilhando foto:', photo.id);
  };

  return (
    <div className="min-h-screen bg-white pb-12" style={{ fontFamily: 'var(--font-sans)' }}>
      {/* Header */}
      <header className="sticky top-0 bg-white/95 backdrop-blur-sm border-b border-border z-10 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-5 h-5" />
            <span>Voltar</span>
          </Link>
          <h1 
            className="text-2xl md:text-3xl"
            style={{ fontFamily: 'var(--font-serif)' }}
          >
            Galeria de Fotos
          </h1>
          <div className="w-20"></div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 pt-8">
        {/* Filter Tabs */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="flex gap-3 mb-8"
        >
          <button
            onClick={() => setFilter('recent')}
            className={`px-6 py-3 rounded-xl transition-all duration-300 flex items-center gap-2 ${
              filter === 'recent'
                ? 'bg-primary text-white shadow-md'
                : 'bg-sand text-foreground hover:bg-muted'
            }`}
          >
            <Clock className="w-4 h-4" />
            Mais recentes
          </button>
          <button
            onClick={() => setFilter('featured')}
            className={`px-6 py-3 rounded-xl transition-all duration-300 flex items-center gap-2 ${
              filter === 'featured'
                ? 'bg-primary text-white shadow-md'
                : 'bg-sand text-foreground hover:bg-muted'
            }`}
          >
            <Star className="w-4 h-4" />
            Destaques
          </button>
        </motion.div>

        {/* Photo Count */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-muted-foreground mb-6"
        >
          {filteredPhotos.length} {filteredPhotos.length === 1 ? 'foto' : 'fotos'}
        </motion.p>

        {/* Masonry Grid */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
        >
          <Masonry columnsCount={3} gutter="1rem" className="max-md:hidden">
            {filteredPhotos.map((photo, index) => (
              <PhotoCard 
                key={photo.id} 
                photo={photo} 
                index={index}
                onClick={() => setSelectedPhoto(photo)}
                onShare={() => handleShare(photo)}
              />
            ))}
          </Masonry>

          {/* Mobile: 2 columns */}
          <Masonry columnsCount={2} gutter="0.75rem" className="md:hidden">
            {filteredPhotos.map((photo, index) => (
              <PhotoCard 
                key={photo.id} 
                photo={photo} 
                index={index}
                onClick={() => setSelectedPhoto(photo)}
                onShare={() => handleShare(photo)}
              />
            ))}
          </Masonry>
        </motion.div>
      </div>

      {/* Photo Modal */}
      <Dialog.Root open={!!selectedPhoto} onOpenChange={() => setSelectedPhoto(null)}>
        <AnimatePresence>
          {selectedPhoto && (
            <Dialog.Portal forceMount>
              <Dialog.Overlay asChild>
                <motion.div
                  className="fixed inset-0 bg-black/90 z-50"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                />
              </Dialog.Overlay>
              <Dialog.Content asChild>
                <motion.div
                  className="fixed inset-0 z-50 flex items-center justify-center p-6"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ type: "spring", damping: 25, stiffness: 300 }}
                >
                  <div className="relative max-w-5xl w-full">
                    <Dialog.Close asChild>
                      <button className="absolute -top-12 right-0 text-white hover:text-gold transition-colors p-2">
                        <X className="w-8 h-8" />
                      </button>
                    </Dialog.Close>
                    
                    <img
                      src={selectedPhoto.url}
                      alt="Photo"
                      className="w-full max-h-[80vh] object-contain rounded-2xl"
                    />
                    
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-6 rounded-b-2xl">
                      <div className="flex items-center justify-between text-white">
                        <div>
                          <p className="text-lg mb-1">{selectedPhoto.guestName}</p>
                          <p className="text-sm text-white/70">{selectedPhoto.timestamp}</p>
                        </div>
                        <button
                          onClick={() => handleShare(selectedPhoto)}
                          className="p-3 bg-white/20 hover:bg-white/30 rounded-full transition-colors"
                        >
                          <Share2 className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              </Dialog.Content>
            </Dialog.Portal>
          )}
        </AnimatePresence>
      </Dialog.Root>
    </div>
  );
}

interface PhotoCardProps {
  photo: Photo;
  index: number;
  onClick: () => void;
  onShare: () => void;
}

function PhotoCard({ photo, index, onClick, onShare }: PhotoCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05, duration: 0.5 }}
      className="relative group cursor-pointer overflow-hidden rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300"
      onClick={onClick}
    >
      <img
        src={photo.url}
        alt={`Photo by ${photo.guestName}`}
        className="w-full h-auto block"
      />
      
      {/* Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
        <div className="absolute bottom-0 left-0 right-0 p-4">
          <p className="text-white text-sm mb-1">{photo.guestName}</p>
          <p className="text-white/70 text-xs">{photo.timestamp}</p>
        </div>
        
        <button
          onClick={(e) => {
            e.stopPropagation();
            onShare();
          }}
          className="absolute top-4 right-4 p-2 bg-white/20 hover:bg-white/30 rounded-full transition-colors"
        >
          <Share2 className="w-4 h-4 text-white" />
        </button>
      </div>

      {/* Featured Badge */}
      {photo.featured && (
        <div className="absolute top-4 left-4 bg-gold text-white px-3 py-1 rounded-full text-xs flex items-center gap-1">
          <Star className="w-3 h-3" fill="currentColor" />
          Destaque
        </div>
      )}
    </motion.div>
  );
}
